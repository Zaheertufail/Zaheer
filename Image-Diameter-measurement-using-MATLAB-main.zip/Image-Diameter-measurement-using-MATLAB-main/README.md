## Aim
Measurement of diameter of an object in an image via MATLAB 

## Process
Through this application one will be able to write a MATLAB script file to import an image,
segment the image in order to isolate the desired object from its background and then use the
MATLAB functions that come with the Image Processing Toolbox to determine the objects
diameter. 

## Image Used
![image used](https://github.com/souvik0306/Image-Diameter/blob/main/ball.jpg?raw=true)
